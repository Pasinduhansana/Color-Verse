import React from "react";
import bgimg2 from "../assets/PaintedBed.jpg";
import { useInView } from "react-intersection-observer";
import { motion } from "framer-motion";

const Perfecting_Card = () => {
  const [ref1, inView1] = useInView({ triggerOnce: false, threshold: 0.1 });

  return (
    <>
      <motion.div
        className="flex flex-col lg:flex-row  justify-center items-center px-6 py-10 gap-10 lg:px-20 md:px-10 select-none"
        ref={ref1}
        initial={{ opacity: 0, y: -150 }} // Start off-screen
        animate={inView1 ? { opacity: 1, y: 0 } : { opacity: 0, y: 150 }} // Animate based on inView1
        transition={{ duration: 0.5, delay: 0.1 }}
      >
        <div className="flex flex-row lg:w-full lg:h-[60vh] md:w-[70vw] md:h-[60vh] overflow-hidden rounded-[20px] gap-1 min-w-[46vw] ">
          <img src={bgimg2} alt="image" className="object-cover  w-full" />
        </div>

        <div className="flex md:flex lg:flex flex-col lg:gap-4 text-wrap mx-4 md:mx-1 justify-center gap-3">
          <span className="text-[18px] lg:text-[30px] md:text-[14px] font-semibold opacity-90 lg:text-left text-center lg:text-wrap">
            Rediscover Wallpaper
          </span>
          <span className="lg:text-[15px] md:text-[12px] text-[12px]  font-normal opacity-65 lg:text-left text-center lg:text-wrap">
            With our revised range, prepare to fall in love with wallpaper all
            over again. We’ve brought back archived favourites and reimaged a
            few of our best-loved designs in new colours."
          </span>
          <button className="px-6 mt-4 py-2 text-[13px] self-center lg:self-start  md:text-[12px] lg:text-[14px] w-auto lg:w-[200px] lg:h-[44px] rounded-full md:mt-2 lg:mt-8 lg:mb-4 bg-[#201e37] lg:font-medium text-white hover:scale-110 duration-300 transition-all">
            Shop Wallpaper
          </button>
        </div>
      </motion.div>
    </>
  );
};

export default Perfecting_Card;
