import { Carousel } from "@material-tailwind/react";
import { Button } from "@material-tailwind/react";
import { useNavigate } from "react-router-dom";
import React, { useState, useEffect } from "react";

//Import Images - White mode

import { useInView } from "react-intersection-observer";
import { motion } from "framer-motion";

import white_img1 from "../assets/interior_img1.jpg";
import white_img2 from "../assets/interior_img2.jpg";
import white_img3 from "../assets/interior_img3.jpg";
import white_img4 from "../assets/interior_img4.jpg";
import white_img5 from "../assets/interior_img5.jpg";
import white_img6 from "../assets/interior_img6.jpg";
import white_img7 from "../assets/interior_img7.jpg";
import white_img8 from "../assets/interior_img8.jpg";
import white_img9 from "../assets/interior_img9.jpg";
import white_img10 from "../assets/interior_img10.jpg";
import white_img11 from "../assets/interior_img11.jpg";
import white_img12 from "../assets/interior_img12.jpg";

const cardData = [
  {
    text: "Wild Flower Diamond Drop Necklace",
    imageUrl: white_img1,
    text1: "Wild Flower Diamond Drop Necklace",
    imageUrl1: white_img2,
    text2: "Wild Flower Diamond Drop Necklace",
    imageUrl2: white_img3,
  },
  {
    text: "Wild Flower Diamond Drop Necklace",
    imageUrl: white_img4,
    text1: "Wild Flower Diamond Drop Necklace",
    imageUrl1: white_img5,
    text2: "Wild Flower Diamond Drop Necklace",
    imageUrl2: white_img6,
  },
  {
    text: "Wild Flower Diamond Drop Necklace",
    imageUrl: white_img7,
    text1: "Wild Flower Diamond Drop Necklace",
    imageUrl1: white_img8,
    text2: "Wild Flower Diamond Drop Necklace",
    imageUrl2: white_img9,
  },
  {
    text: "Wild Flower Diamond Drop Necklace",
    imageUrl: white_img10,
    text1: "Wild Flower Diamond Drop Necklace",
    imageUrl1: white_img11,
    text2: "Wild Flower Diamond Drop Necklace",
    imageUrl2: white_img12,
  },
];

const cardData1 = [
  {
    text: "Modern Minimalist Living Room",
    imageUrl: white_img1,
  },
  {
    text: "Scandinavian Coffee Table",
    imageUrl: white_img2,
  },
  {
    text: "Industrial Style Bookshelf",
    imageUrl: white_img3,
  },
  {
    text: "Rustic Wooden Dining Table",
    imageUrl: white_img4,
  },
  {
    text: "Contemporary Armchair",
    imageUrl: white_img5,
  },
  {
    text: "Vintage Area Rug",
    imageUrl: white_img6,
  },
  {
    text: "Elegant Floor Lamp",
    imageUrl: white_img7,
  },
  {
    text: "Art Deco Wall",
    imageUrl: white_img8,
  },
  {
    text: "Luminess Metting Room",
    imageUrl: white_img9,
  },
  {
    text: "Minimal Blue Sofa",
    imageUrl: white_img10,
  },
  {
    text: "Luxurious Officespread",
    imageUrl: white_img11,
  },
  {
    text: "Stylish Wall Paint",
    imageUrl: white_img12,
  },
];
const CarouselCustomNavigation = () => {
  const [ref1, inView1] = useInView({ triggerOnce: false, threshold: 0.1 });
  const black_card_colour = "#9a9a9a46";

  const navigate = useNavigate();

  const handleButtonClick = () => {
    navigate("/gallery");
  };

  const [isMobile, setIsMobile] = useState(window.innerWidth < 768); // 768px for mobile

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 768); // Update based on screen width
    };

    window.addEventListener("resize", handleResize);
    return () => {
      window.removeEventListener("resize", handleResize);
    };
  }, []);

  return (
    <div className="flex flex-col md:flex-col p-10 gap-3 items-center bg-white">
      <div className="text-card flex flex-col content-center text-center text-gray-900 gap-2 my-5 max-w-auto ">
        <h1 className="text-[35px] font-semibold">
          Inspiration for your project
        </h1>
        <p className="text-[14px] font-normal text-gray-500 px-5">
          Discover fresh ideas and creative solutions to transform your space.
        </p>
      </div>

      {isMobile ? (
        <Carousel
          className="rounded-xl"
          autoplay="True"
          autoplayDelay="9000"
          loop="True"
          navigation={({ setActiveIndex, activeIndex, length }) => (
            <div className="absolute bottom-4 left-2/4 z-50 flex -translate-x-2/4 gap-2">
              {new Array(length).fill("").map((_, i) => (
                <span
                  key={i}
                  className={`block h-1 cursor-pointer rounded-2xl transition-all content-[''] ${
                    activeIndex === i ? "w-8 bg-white" : "w-4 bg-white/50"
                  }`}
                  onClick={() => setActiveIndex(i)}
                />
              ))}
            </div>
          )}
        >
          {cardData1.map((card, index) => (
            <div
              key={index}
              className="relative h-[350px] w-full flex flex-row gap-2 bottom-10 mt-10 overflow-hidden justify-center"
              ref={ref1}
              initial={{ opacity: 0, y: -150 }} // Start off-screen
              animate={inView1 ? { opacity: 1, y: 0 } : { opacity: 0, y: 150 }} // Animate based on inView1
              transition={{ duration: 0.6 }}
            >
              <div className="card1 h-[350px]  rounded-[20px] overflow-hidden  ">
                <img
                  src={card.imageUrl}
                  alt={`image ${index + 1}`}
                  className="h-full w-full object-cover"
                />
                <div
                  className="relative flex-col bottom-[50px]  left-0 right-0 backdrop-blur-[10px] h-10 transition-all mx-3 rounded-[2rem] group-hover:backdrop-blur-none items-center content-center"
                  style={{ backgroundColor: black_card_colour }}
                >
                  <p className="text-[14px] font-[500] text-gray-900 px-5 transition-all font-poppins group-hover:text-white text-wrap">
                    {card.text}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </Carousel>
      ) : (
        <Carousel
          className="rounded-xl overflow-hidden"
          autoplay="False"
          autoplayDelay="9000"
          loop="True"
          navigation={({ setActiveIndex, activeIndex, length }) => (
            <motion.div
              className="absolute bottom-4 left-2/4 z-50 flex -translate-x-2/4 gap-2"
              ref={ref1}
              initial={{ opacity: 0, y: -150 }} // Start off-screen
              animate={inView1 ? { opacity: 1, y: 0 } : { opacity: 0, y: 150 }} // Animate based on inView1
              transition={{ duration: 0.6 }}
            >
              {new Array(length).fill("").map((_, i) => (
                <span
                  key={i}
                  className={`block h-1 cursor-pointer rounded-2xl transition-all content-[''] ${
                    activeIndex === i ? "w-8 bg-gray-700" : "w-4 bg-gray-400"
                  }`}
                  onClick={() => setActiveIndex(i)}
                />
              ))}
            </motion.div>
          )}
        >
          {cardData.map((card, index) => (
            <div
              key={index}
              className="relative h-[auto] w-full flex flex-row gap-2 bottom-10 mt-10 overflow-hidden justify-evenly"
            >
              <div className="card1 h-[60vh]  rounded-[20px] overflow-hidden ">
                <img
                  src={card.imageUrl}
                  alt={`image ${index + 1}`}
                  className="h-full w-full object-cover"
                />
                <div
                  className="relative flex-col bottom-[50px]  left-0 right-0 backdrop-blur-[10px] h-10 transition-all mx-3 rounded-[2rem] group-hover:backdrop-blur-none items-center content-center"
                  style={{ backgroundColor: black_card_colour }}
                >
                  <p className="text-[14px] font-[500] text-gray-900 px-5 transition-all font-poppins group-hover:text-white text-wrap">
                    {card.text}
                  </p>
                </div>
              </div>

              <div className="card2 h-[60vh]  rounded-[20px] overflow-hidden">
                <img
                  src={card.imageUrl1}
                  alt={`image ${index + 1}`}
                  className="h-full w-full object-cover"
                />
                <div
                  className="relative flex-col bottom-[50px]  left-0 right-0 backdrop-blur-[10px] h-10 transition-all mx-3 rounded-[2rem] group-hover:backdrop-blur-none items-center content-center"
                  style={{ backgroundColor: black_card_colour }}
                >
                  <p className="text-[14px] font-[500] text-gray-900 px-5 transition-all font-poppins group-hover:text-white text-wrap">
                    {card.text1}
                  </p>
                </div>
              </div>

              <div className="card3 h-[60vh]  rounded-[20px] overflow-hidden">
                <img
                  src={card.imageUrl2}
                  alt={`image ${index + 1}`}
                  className="h-full w-full object-cover"
                />
                <div
                  className="relative flex-col bottom-[50px]  left-0 right-0 backdrop-blur-[10px] h-10 transition-all mx-3 rounded-[2rem] group-hover:backdrop-blur-none items-center content-center"
                  style={{ backgroundColor: black_card_colour }}
                >
                  <p className="text-[14px] font-[500] text-gray-900 px-5 transition-all font-poppins group-hover:text-white text-wrap">
                    {card.text2}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </Carousel>
      )}
    </div>
  );
};

export default CarouselCustomNavigation;
