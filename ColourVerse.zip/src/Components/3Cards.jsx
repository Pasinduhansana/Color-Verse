import React from "react";
import image1 from "../assets/ColourCard1.jpg";
import image2 from "../assets/sticker.jpg";
import image3 from "../assets/Pots.jpg";
import { useInView } from "react-intersection-observer";
import { motion } from "framer-motion";

const cardData = [
  {
    image: image1,
    title: "Your Free Colour Card",
    description:
      "Our carefully curated palette of 132 shades, with an intriguing story behind each colour name, will help you to choose colours you love for your home.",
    buttonText: "Order Your Colour Card",
  },
  {
    image: image2,
    title: "Sample Pots",
    description:
      "The best way to experience our colours at home before taking the plunge is with a true-to-colour paint sample (or two, or five) - with free delivery.",
    buttonText: "Buy Your Sample",
  },
  {
    image: image3,
    title: "Our Wallpaper",
    description:
      "Subtle neutral or striking metallic, delicate floral or classic stripe - whatever your style, you'll find it among our handcrafted wallpapers.",
    buttonText: "Shop Wallpaper",
  },
];

const Cards3 = () => {
  const [ref1, inView1] = useInView({ triggerOnce: false, threshold: 0.1 });
  return (
    <>
      <motion.div
        className="flex flex-col lg:flex-row self-center lg:justify-evenly lg:px-20 "
        ref={ref1}
        initial={{ opacity: 0, y: -150 }} // Start off-screen
        animate={inView1 ? { opacity: 1, y: 0 } : { opacity: 0, y: 150 }} // Animate based on inView1
        transition={{ duration: 0.5, delay: 0.1 }}
      >
        {cardData.map((data, index) => (
          <motion.div
            key={index}
            className="flex flex-col mb-6 lg:justify-center lg:items-center pb-6"
            ref={ref1}
            initial={{ opacity: 0, y: -150 }} // Start off-screen
            animate={inView1 ? { opacity: 1, y: 0 } : { opacity: 0, y: 150 }} // Animate based on inView1
            transition={{ duration: 0.5, delay: 0.2 * index }}
          >
            <div className="mx-14 my-3 rounded-full overflow-hidden lg:w-[10vw] ">
              <img src={data.image} alt="" />
            </div>
            <div className="flex flex-col gap-2 text-center">
              <span className="text-[19px] font-semibold opacity-85">
                {data.title}
              </span>
              <span className="text-[13px] font-normal mx-10 opacity-75 lg:w-[20vw]">
                {data.description}
              </span>

              <a
                href="#"
                className="text-gray-700 hover:text-white transition-colors duration-200 underline font-semibold text-[14px]"
              >
                {data.buttonText}
              </a>
            </div>
          </motion.div>
        ))}
      </motion.div>
    </>
  );
};

export default Cards3;
