import { React, useEffect, useState, useRef } from "react";
import CardWithText from "./CardWithText";
import Rediscover from "./Rediscover";
import ColoursOfAutumn from "./ColoursOfAutumn";
import ColorCardOrder from "./ColorCardOrder";
import Explore_Card from "./Explore_Card";
import Logo from "../assets/Logo1.png";
import Projectideas from "../Components/ProjectIdeas";
import Project_ideas_Carousel from "../Components/Project_Ideas_Carousel";
import { useInView } from "react-intersection-observer";
import { motion } from "framer-motion";
import Card3 from "./3Cards";
import Pefecting_Card from "./Perfecting_Card";
import FullImage_Card from "./FullImage_Card";
import StripeCard from "./Stripe_Card";

//import images
import wallpaint from "../assets/wallpaint.png";

const Home = () => {
  const [ref1, inView1] = useInView({ triggerOnce: false, threshold: 0.1 });

  return (
    <div>
      <main className="w-screen overflow-hidden">
        <section className="video-container">
          <div className="video-background-container">
            <iframe
              className="video-background"
              src={
                "https://www.youtube.com/embed/kWSHdixzMco?autoplay=1&mute=1&loop=1&controls=0&showinfo=0&start=30&showinfo=0&vq=hd1080&modestbranding=1"
              }
              frameborder="0"
              allow="autoplay; fullscreen"
              allowfullscreen
            ></iframe>
          </div>
          {/* <iframe
            className="video-background"
            src={
              "https://www.youtube.com/embed/kWSHdixzMco?autoplay=1&mute=1&loop=1&playlist=kWSHdixzMco&controls=0&showinfo=0&modestbranding=1&start=30"
            }
            frameborder="0"
            allow="autoplay; encrypted-media"
            allowfullscreen
          ></iframe> */}

          <div className="absolute inset-0 flex flex-col justify-center  text-white text-center px-4 top-10 select-none">
            <div className="flex flex-col rounded-[15px] bg-[#13112062] backdrop-blur-[13px] w-[auto] lg:w-[50vw] h-[70vh] self-center items-center justify-center px-5 pb-8">
              <img
                src={Logo}
                alt="Farrow & Ball Logo"
                className="mb-0 w-48 h-48"
              />
              <h1 className="text-[28px] font-semibold mx-0 px-0">
                Transform your home with colour consultancy
              </h1>
              <p className="mt-5 mb-4 mx-1 text-[14px] font-thin opacity-75">
                Whether you want a colourful cottage, a tasteful townhouse or a
                Scandi-style studio, a Farrow & Ball colour consultancy gives
                you everything you need for the perfect palette.
              </p>
              <div className="flex flex-wrap justify-center gap-2 md:gap-6">
                <button className="px-8 text-[14px] py-2 bg-[#ffffff6e] hover:bg-gray-50 w-[40] lg:w-auto text-gray-900 rounded-full mt-2  border-none outline-none focus:outline-none transition-all duration-300 hover:scale-[1.2]">
                  Find Out More
                </button>
                <button className="px-8 text-[14px] py-2 bg-[#ffffff6e] hover:bg-gray-50 w-[40] lg:w-auto text-gray-900 rounded-full mt-2 border-none outline-none focus:outline-none transition-all duration-300 hover:scale-[1.2] ">
                  Book Now
                </button>
              </div>
            </div>
          </div>
        </section>

        <section className="bg-[#ffffff] pt-16">
          <div className="mx-[6vw] bg-gradient-to-r from-[#1c1e42] to-[#192331] rounded-xl text-white w-auto">
            <CardWithText
              id="card-with-text-1"
              imgSrc={wallpaint}
              title="Start Your Transformation"
              text="When you order two sample pots, we’ll gift you a third for free – on the house to help create your home. Simply add three (or six, or nine) pots to your basket and the discount will be applied automatically."
              buttonText="Order Now"
            />
          </div>
        </section>

        <section className="mx-[5vw] p-4 w-auto">
          <hr className="mb-[3rem] mt-[2rem] border-gray-400" />
          <StripeCard />
        </section>

        <div class="border-b border-gray-300 mx-12 bg-white"></div>

        <Rediscover />

        <div class="border-b border-gray-300 mx-12 bg-white"></div>

        <Project_ideas_Carousel />

        <div class="border-b border-gray-300 mx-12 bg-white"></div>

        <Explore_Card />

        <div class="border-b border-gray-300 mx-12 bg-white"></div>

        <section className="bg-white py-2 lg:py-10 w-screen">
          <div className="mx-2 lg:mx-6 px-4 self-center items-center">
            <ColorCardOrder />
          </div>
        </section>

        <div class="border-b border-gray-300 mx-12 bg-white"></div>

        <section className="bg-white py-2 lg:py-6 w-screen">
          <div className="mx-2 lg:mx-6 px-4 self-center items-center">
            <ColoursOfAutumn />
          </div>
        </section>

        <div class="border-b border-gray-300 mx-12 bg-white"></div>

        <section className="bg-white py-2 lg:py-6 w-screen">
          <Card3 />
        </section>

        <div class="border-b border-gray-300 mx-12 bg-white"></div>

        <section className="bg-white py-2 lg:py-6 w-screen">
          <Pefecting_Card />
        </section>

        <div class="border-b border-gray-300 mx-12 bg-white"></div>

        <div class="border-b border-gray-300 lg:mx-12 mx-6 bg-white">
          <FullImage_Card />
        </div>
      </main>
    </div>
  );
};

export default Home;
