import React from "react";
import { Button } from "@material-tailwind/react";
import img1 from "../assets/interior_img1.jpg";
import img2 from "../assets/interior_img2.jpg";
import img3 from "../assets/interior_img3.jpg";
import img4 from "../assets/interior_img4.jpg";
import img5 from "../assets/interior_img5.jpg";
import img6 from "../assets/interior_img6.jpg";
import img7 from "../assets/interior_img7.jpg";
import img8 from "../assets/interior_img8.jpg";
import img9 from "../assets/interior_img9.jpg";

import { useInView } from "react-intersection-observer";
import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

const cardData = [
	{
		image: img1,
		title: "Office Ideas",
		buttonText: "View Gallery",
	},
	{
		image: img2,
		title: "Office Ideas",
		buttonText: "View Gallery",
	},
	{
		image: img3,
		title: "Office Ideas",
		buttonText: "View Gallery",
	},
	{
		image: img4,
		title: "Office Ideas",
		buttonText: "View Gallery",
	},
	{
		image: img5,
		title: "Office Ideas",
		buttonText: "View Gallery",
	},
	{
		image: img6,
		title: "Office Ideas",
		buttonText: "View Gallery",
	},
	{
		image: img7,
		title: "Office Ideas",
		buttonText: "View Gallery",
	},
	{
		image: img8,
		title: "Office Ideas",
		buttonText: "View Gallery",
	},
	{
		image: img9,
		title: "Office Ideas",
		buttonText: "View Gallery",
	},
];

const TriCards = () => {
	const [ref1, inView1] = useInView({ triggerOnce: false, threshold: 0.1 });
	const navigate = useNavigate();

	const handleButtonClick = () => {
		navigate("/");
	};

	// Carousel settings
	const settings = {
		dots: true,
		infinite: true,
		speed: 500,
		slidesToShow: 4,
		slidesToScroll: 1,
		arrows: true,
		swipe: true,
		responsive: [
			{
				breakpoint: 1024,
				settings: {
					slidesToShow: 3,
				},
			},
			{
				breakpoint: 768,
				settings: {
					slidesToShow: 7,
				},
			},
			{
				breakpoint: 480,
				settings: {
					slidesToShow: 1,
				},
			},
		],
	};

	return (
		<>
			<div className="flex flex-col mt-10">
				{/* Title Section */}
				<motion.div
					className="flex flex-col text-gray-800 items-center lg:items-center mb-6 px-8 lg:px-0 sm:items-center"
					ref={ref1}
					initial={{
						opacity: 0,
						y: window.innerWidth >= 1024 ? 150 : 0,
					}}
					animate={inView1 ? { opacity: 1, y: 0 } : { opacity: 0, y: 150 }}
					transition={{ duration: 0.6, delay: 0 }}
				>
					<h1 className="text-gray-800 text-[32px] font-semibold uppercase">
						The House of Bijou
					</h1>
					<p className="text-gray-600 text-[16px] text-center mt-2">Featured</p>
				</motion.div>

				{/* Desktop view */}
				<div className="hidden lg:flex flex-row gap-10 text-gray-900 p-8">
					{/* Card components using JSON */}
					<Slider {...settings}>
						{cardData.map((card, index) => (
							<div key={index} className="text-center">
								<div className="h-auto w-[250px] rounded-[10px] m-2 shadow-[0_2px_16px_rgba(0,0,0,0.19)]">
									<img
										src={card.image}
										alt={card.title}
										className="h-full w-full object-cover"
									/>
								</div>
								<h1 className="text-gray-800 text-[24px] font-semibold">
									{card.title}
								</h1>

								<Button
									variant="outlined"
									className="w-[250px] h-[40px] rounded-0 self-center mt-4 text-[#2f2f2f] border-[#2f2f2f] hover:bg-gradient-to-r hover:from-[#f6ae29] hover:to-[#f68529] hover:text-[#ffffff] hover:border-white hover:shadow-lg transition-all duration-300 ease-in-out focus:shadow-none uppercase"
									onClick={handleButtonClick}
								>
									{card.buttonText}
								</Button>
							</div>
						))}
					</Slider>
				</div>

				{/* Mobile view */}
				<div className="lg:hidden p-8">
					<Slider {...settings}>
						{cardData.map((card, index) => (
							<div key={index} className="text-center">
								<div className="h-[auto] overflow-hidden rounded-[10px] m-2 shadow-[0_2px_16px_rgba(0,0,0,0.19)]">
									<img
										src={card.image}
										alt={card.title}
										className="h-full w-full object-cover"
									/>
								</div>
								<h1 className="text-gray-800 text-[24px] font-semibold">
									{card.title}
								</h1>
								<Button
									variant="outlined"
									className="w-[250px] h-[40px] rounded-0 self-center mt-4 text-[#2f2f2f] border-[#2f2f2f] hover:bg-gradient-to-r hover:from-[#f6ae29] hover:to-[#f68529] hover:text-[#ffffff] hover:border-white hover:shadow-lg transition-all duration-300 ease-in-out focus:shadow-none uppercase"
									onClick={handleButtonClick}
								>
									{card.buttonText}
								</Button>
							</div>
						))}
					</Slider>
				</div>
			</div>
		</>
	);
};

export default TriCards;
