import {
  UserCircleIcon,
  Cog6ToothIcon,
  InboxArrowDownIcon,
  LifebuoyIcon,
  PowerIcon,
} from "@heroicons/react/24/solid";
import { ChevronDownIcon } from "@heroicons/react/24/outline";
import {
  Button,
  IconButton,
  Avatar,
  Menu,
  MenuHandler,
  MenuList,
  MenuItem,
  Typography,
} from "@material-tailwind/react";
import profile_img from "../assets/profileimage.webp";
import { FaSearch } from "react-icons/fa";
import React, { useState, useEffect } from "react";
import logo from "../assets/Logo1.png";

import img1 from "../assets/Paints/Blue.jpg";
import img2 from "../assets/Paints/Green.jpg";
import img3 from "../assets/Paints/Red.jpg";
import img4 from "../assets/Paints/Purple.jpg";

function Header() {
  const [isNavOpen, setIsNavOpen] = useState(false);
  const [hoveredLink, setHoveredLink] = useState("");
  const [showSubMenu, setShowSubMenu] = useState(false);

  const toggleNav = () => {
    setIsNavOpen(!isNavOpen);
  };

  const toggleSubMenu = (link) => {
    if (showSubMenu && hoveredLink === link) {
      setShowSubMenu(false);
      setHoveredLink("");
    } else {
      setHoveredLink(link);
      setShowSubMenu(true);
    }
  };

  // Close submenu when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      const subMenu = document.getElementById("submenu");
      if (subMenu && !subMenu.contains(event.target)) {
        setShowSubMenu(false);
        setHoveredLink("");
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  const subContent = {
    Paint: [
      {
        img: img1,
        text: "Red Paint",
        colorName: "Red",
        color: "#FF0000",
      },
      {
        img: img2,
        text: "Blue Paint",
        colorName: "Blue",
        color: "#0000FF",
      },
      {
        img: img3,
        text: "Green Paint",
        colorName: "Green",
        color: "#008000",
      },
      {
        img: img4,
        text: "Purple Paint",
        colorName: "Purple",
        color: "#A020F0",
      },
    ],
    Wallpaper: [
      {
        text: "Geometric Wallpapers",
      },
      {
        text: "Striped Wallpapers",
      },
      {
        text: "Metallic Wallpapers",
      },
      {
        text: "Floral Wallpapers",
      },
      {
        text: "Damask Wallpapers",
      },
      {
        text: "Scenic Wallpapers",
      },
    ],
    "Colour Consultancy": [
      {
        text: "What Is Colour Consultancy?",
      },
      {
        text: "Book Your Colour Consultancy",
      },
      {
        text: "Enquire About A Consultancy",
      },
      {
        text: "Meet Our Experts",
      },
      {
        text: "Book Joa Studholme",
      },
      {
        text: "Book Patrick O'Donnell",
      },
      {
        text: "Transformations",
      },
      {
        text: "English Cottage",
      },
      {
        text: "Paris Apartment",
      },
      {
        text: "Munich Apartment",
      },
      {
        text: "Georgian Townhouse",
      },
      {
        text: "Texas Hideaway",
      },
    ],
  };

  return (
    <header className="bg-[#13112062] backdrop-blur-[13px] bg-opacity-30 absolute top-0 left-0 w-full z-50  h-[90px]">
      <nav className="container mx-auto flex lg:flex-row md:flex-row bottom-10 flex-col items-center justify-between p-2">
        {/* Logo Section */}
        <div className="lg:flex md:flex items-cente ">
          <img src={logo} alt="Logo" className="h-20 pb-0" />
        </div>

        {/* Navigation Links */}
        <div
          className={`flex items-center space-x-4 relative md:flex mt-6 md:mt-0 lg-mt-0 md:space-x-4 ${
            isNavOpen ? "block" : "hidden"
          } md:block`}
        >
          {["Paint", "Wallpaper", "Colour Consultancy"].map((item) => (
            <div
              key={item}
              className="relative"
              onClick={() => toggleSubMenu(item)}
              onMouseEnter={() => setHoveredLink(item)}
              onMouseLeave={() => setHoveredLink("")}
            >
              <span className="text-gray-300 hover:text-gray-300 cursor-pointer flex items-center  lg:mx-5 text-[12px] lg:text-[15px]">
                {item}
                <ChevronDownIcon className="h-5 w-5 ml-1" />
              </span>

              {showSubMenu && hoveredLink === item && (
                <div
                  id="submenu"
                  className="absolute left-0 mt-2 w-80 bg-[#ffffffc1] backdrop-blur-[16px] rounded-lg shadow-lg p-2"
                  onMouseEnter={() => setHoveredLink(item)} // Keep submenu open on hover
                  onMouseLeave={() => setHoveredLink("")} // Close submenu when mouse leaves
                >
                  {item === "Paint"
                    ? // Render Paint submenu with images
                      subContent[item].map((subItem, index) => (
                        <div
                          key={index}
                          className="lg:flex items-center mt-1 cursor-pointer hover:bg-gray-100 w-full"
                        >
                          <img
                            src={subItem.img}
                            alt={subItem.text}
                            className="w-12 h-12 rounded-full"
                          />
                          <span className="mx-4 text-[13px]">
                            {subItem.text}
                          </span>
                        </div>
                      ))
                    : // Render Wallpaper and Colour Consultancy submenu as a list
                      subContent[item].map((subItem, index) => (
                        <div
                          key={index}
                          className="flex items-center mt-1 cursor-pointer hover:bg-gray-100 w-full"
                        >
                          <span className="mx-4 my-2 text-[13px]">
                            {subItem.text}
                          </span>
                        </div>
                      ))}
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Search Bar Section */}
        <div className="relative hidden lg:flex items-center mx-4 lg:h-30px justify-end">
          <div className="relative flex items-center mx-4 justify-end">
            <input
              type="search"
              placeholder="Search..."
              className="lg:p-2 pl-2 w-80 rounded-md text-gray-300 bg-white bg-opacity-30 text-[14px] font-normal  backdrop-blur-md border border-transparent focus:outline-none focus:scale-105 focus:ring-0 transition duration-300"
            />
          </div>

          {/* Profile and Login Button */}
          <div className="flex items-center space-x-2">
            <button className="bg-gradient-to-r from-[#222222]  to-[#242424] text-gray-300 p-2 w-[80px] text-[14px] font-normal rounded-md transition duration-300 hover:scale-105 focus:outline-none focus:ring-0 active:outline-none active:ring-0">
              Search
            </button>
            <button className="bg-gradient-to-r from-[#222222]  to-[#242424] text-gray-300 p-2 w-[80px] text-[14px] font-normal rounded-md transition duration-300 hover:scale-105 focus:outline-none focus:ring-0 active:outline-none active:ring-0">
              Login
            </button>
          </div>
        </div>
      </nav>
    </header>
  );
}

export default Header;
