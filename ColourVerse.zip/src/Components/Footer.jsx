import { React, useState, useEffect } from "react";
import Logo from "../assets/Logo1.png";
import { styled } from "@mui/material/styles";
import Box from "@mui/material/Box";
import Rating from "@mui/material/Rating";
import { Carousel } from "@material-tailwind/react";

//import Icons
import FavoriteBorderIcon from "@mui/icons-material/StarBorderPurple500";
import FavoriteIcon from "@mui/icons-material/Star";
import Rating_json from "../Json Files/Ratings.json";
import VerifiedIcon from "@mui/icons-material/Verified";

//Import Images
import applepay from "../assets/applepay.png";
import visa from "../assets/visa.webp";
import Mastercard from "../assets/mastercard.webp";
import paypal from "../assets/paypal.webp";

//Define Colour Codes
const secondary_colour = "#03C03C";
const secondary_accent_colour = "#3FFF00";

const StyledRating = styled(Rating)({
  "& .MuiRating-iconFilled": {
    color: secondary_colour,
  },
  "& .MuiRating-iconHover": {
    color: secondary_accent_colour,
  },
});
const Ratings = ({ rate }) => {
  return (
    <Box sx={{ "& > legend": { mt: 2 } }}>
      <StyledRating
        name="customized-color"
        defaultValue={rate}
        getLabelText={(value) => `${value} Heart${value !== 1 ? "s" : ""}`}
        precision={0.5}
        icon={<FavoriteIcon fontSize="inherit" />}
        emptyIcon={<FavoriteBorderIcon fontSize="inherit" />}
        readOnly={true}
      />
    </Box>
  );
};

const Footer = () => {
  const [reviews, setReviews] = useState(Rating_json);
  const [showFullReview, setShowFullReview] = useState(false);
  const maxLength = 10;

  const toggleReview = () => {
    setShowFullReview(!showFullReview);
  };

  return (
    <div className="bg-[#272b4d] text-white p-4 md:p-8 lg:pb-2 w-screen overflow-hidden select-none">
      <div className="flex flex-col lg:flex lg:flex-row lg:text-left text-center justify-center mb-4 lg:justify-between">
        <div className="text-center lg:text-left mr-12 mt-5 ml-8">
          <h2 className="text-2xl font-bold">Excellent</h2>
          <div className="flex items-center justify-center my-2 lg:justify-start">
            <Box sx={{ "& > legend": { mt: 2 } }}>
              <StyledRating
                name="customized-color"
                defaultValue={2}
                getLabelText={(value) =>
                  `${value} Heart${value !== 1 ? "s" : ""}`
                }
                precision={0.5}
                icon={<FavoriteIcon fontSize="inherit" />}
                emptyIcon={<FavoriteBorderIcon fontSize="inherit" />}
                readOnly={false}
              />
            </Box>
          </div>
          <p>
            Based on <span className="text-blue-400">9,934 reviews</span>
          </p>
          <div className="flex items-center my-2 justify-center lg:justify-start">
            <div className="flex items-center lg:justify-center w-8 h-8 transition-transform duration-200 ease-in-out hover:scale-110">
              <VerifiedIcon
                className="text-white w-5 h-5"
                style={{ color: secondary_colour }}
              />
            </div>
            <span className="ml-2">Verified</span>
          </div>
        </div>

        <div className="self-end relative overflow-auto w-[90vw] lg:w-auto">
          <div className="scroll-container flex gap-2 ">
            {reviews.map((review) => (
              <div
                key={review.id}
                className="bg-[#ffffff0e] rounded-[5px] min-h-[200px] flex justify-start items-center flex-col gap-3 p-3 w-[196px] relative"
              >
                {/* Star Rating - Fixed Position */}
                <div className="flex items-center mb-2 text-left justify-start flex-col">
                  <Ratings rate={review.rating} />
                </div>

                {/* Review Text with "Read More" functionality */}
                <div className="relative flex-grow overflow-hidden text-[12px] text-left">
                  {/* Scrollable div for long text */}
                  <div
                    className={`${
                      showFullReview
                        ? "max-h-[200px] overflow-auto"
                        : "max-h-[58.5px] overflow-hidden"
                    } transition-all duration-300 ease-in-out text-wrap`}
                  >
                    <h3 className="font-medium pb-1">{review.review}</h3>
                  </div>

                  {/* Show "Read More" if review text is longer than maxLength */}
                  {review.review.length > maxLength && (
                    <a
                      className="text-[#4cbc99] text-[12px] cursor-pointer hover:text-[#4cbc99]"
                      onClick={toggleReview}
                    >
                      {showFullReview ? "Read Less" : "Read More"}
                    </a>
                  )}
                </div>

                {/* Reviewer Name and Date */}
                <p className="text-gray-400 text-[12px]">
                  {review.name}, {review.date}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
      <div className="border-t border-gray-600 pt-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 text-center md:text-left">
          <div className="flex justify-center items-center">
            <img src={Logo} alt="Farrow & Ball Logo" className="w-auto h-64" />
          </div>

          <div className="flex flex-col">
            <h4 className="font-bold mb-4 text-white ">About Us</h4>
            <ul className="space-y-2">
              <li>
                <a
                  href="#"
                  className="relative text-gray-400 hover:text-white transition-colors duration-200"
                >
                  Sign Up to Our Emails
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="relative text-gray-400 hover:text-white transition-colors duration-200"
                >
                  Social Media
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="relative text-gray-400 hover:text-white transition-colors duration-200"
                >
                  Press
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="relative text-gray-400 hover:text-white transition-colors duration-200"
                >
                  Become An Affiliate
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="relative text-gray-400 hover:text-white transition-colors duration-200"
                >
                  Events
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="relative text-gray-400 hover:text-white transition-colors duration-200"
                >
                  Careers
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="relative text-gray-400 hover:text-white transition-colors duration-200"
                >
                  Gender Pay Report
                </a>
              </li>
            </ul>
          </div>

          <div className="flex flex-col">
            <h4 className="font-bold mb-4 text-gray-100 text-lg">
              Customer Services
            </h4>
            <ul className="space-y-2">
              <li>
                <a
                  href="#"
                  className="text-gray-400 hover:text-white transition-colors duration-200"
                >
                  Delivery & Returns
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="text-gray-400 hover:text-white transition-colors duration-200"
                >
                  Contact Us
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="text-gray-400 hover:text-white transition-colors duration-200"
                >
                  Privacy Policy
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="text-gray-400 hover:text-white transition-colors duration-200"
                >
                  Cookie Policy & Online Security
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="text-gray-400 hover:text-white transition-colors duration-200"
                >
                  Farrow & Ball Showrooms
                </a>
              </li>
            </ul>
          </div>

          <div className="flex flex-col">
            <h4 className="font-bold mb-4">Follow Us</h4>
            <div className="flex justify-center md:justify-start space-x-4 mb-4">
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
              >
                <img
                  src="https://upload.wikimedia.org/wikipedia/commons/a/a5/Instagram_icon.png"
                  alt="Instagram"
                  className="w-8 h-8 hover:scale-[1.3] transition-transform duration-200 ease-in-out hover:opacity-80"
                />
              </a>
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noopener noreferrer"
              >
                <img
                  src="https://upload.wikimedia.org/wikipedia/commons/5/51/Facebook_f_logo_%282019%29.svg"
                  alt="Facebook"
                  className="w-8 h-8 hover:scale-[1.3] transition-transform duration-200 ease-in-out hover:opacity-80"
                />
              </a>
              <a
                href="https://pinterest.com"
                target="_blank"
                rel="noopener noreferrer"
              >
                <img
                  src="https://upload.wikimedia.org/wikipedia/commons/0/08/Pinterest-logo.png"
                  alt="Pinterest"
                  className="w-8 h-8 hover:scale-[1.3] transition-transform duration-200 ease-in-out hover:opacity-80"
                />
              </a>
            </div>

            <h4 className="font-bold mb-4">Pay Securely</h4>
            <div className="flex justify-center md:justify-start space-x-4">
              <a
                href="https://www.apple.com/apple-pay/"
                target="_blank"
                rel="noopener noreferrer"
              >
                <img
                  src={applepay}
                  alt="Apple Pay"
                  className="w-12 h-8 hover:scale-[1.2] transition-transform duration-200 ease-in-out hover:opacity-80"
                />
              </a>
              <a
                href="https://www.visa.com/"
                target="_blank"
                rel="noopener noreferrer"
              >
                <img
                  src={visa}
                  alt="Visa"
                  className="w-12 h-8 hover:scale-[1.2] transition-transform duration-200 ease-in-out hover:opacity-80"
                />
              </a>
              <a
                href="https://www.paypal.com/"
                target="_blank"
                rel="noopener noreferrer"
              >
                <img
                  src={paypal}
                  alt="PayPal"
                  className="w-12 h-8 hover:scale-[1.2] transition-transform duration-200 ease-in-out hover:opacity-80"
                />
              </a>
              <a
                href="https://www.mastercard.us/"
                target="_blank"
                rel="noopener noreferrer"
              >
                <img
                  src={Mastercard}
                  alt="MasterCard"
                  className="w-12 h-8 hover:scale-[1.2] transition-transform duration-200 ease-in-out hover:opacity-80"
                />
              </a>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-600 mt-4 pt-4 pb-0 text-center mb-0 text-[14px]">
          <p className="text-red-50 opacity-40">
            © WebMinds 2024. All Rights Reserved.
          </p>
        </div>
      </div>
    </div>
  );
};

export default Footer;
