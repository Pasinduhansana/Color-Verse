import React from "react";
import { useState, useEffect } from "react";
import { AiOutlineLeft, AiOutlineRight } from "react-icons/ai";
import { useInView } from "react-intersection-observer";
import { motion } from "framer-motion";

// import images
import img1 from "../assets/Colours/color1.webp";
import img2 from "../assets/Colours/color2.webp";
import img3 from "../assets/Colours/color3.webp";
import img4 from "../assets/Colours/color4.webp";
import img5 from "../assets/Colours/color5.webp";
import img6 from "../assets/Colours/color6.webp";
import img7 from "../assets/Colours/color7.webp";
import img8 from "../assets/Colours/color8.webp";
import img9 from "../assets/Colours/color9.webp";

const Carousel = () => {
  const [ref1, inView1] = useInView({ triggerOnce: false, threshold: 0.1 });

  const images = [
    {
      src: img1,
      title: "Print Room Yellow",
      no: "No : 152",
    },
    {
      src: img2,
      title: "Charlotte's locls",
      no: "No : 133",
    },
    {
      src: img3,
      title: "Incarnadine",
      no: "No : 119",
    },
    {
      src: img4,
      title: "Brinjal",
      no: "No : 144",
    },
    {
      src: img5,
      title: "Picture Gallery Red",
      no: "No : 121",
    },
    {
      src: img6,
      title: "Mahogany",
      no: "No : 167",
    },
    {
      src: img7,
      title: "Bancha",
      no: "No : 89",
    },
    {
      src: img8,
      title: "Cardamom",
      no: "No : 182",
    },
    {
      src: img9,
      title: "Studio Green",
      no: "No : 195",
    },
  ];

  const [currentIndex, setCurrentIndex] = useState(0);
  const [itemsToShow, setItemsToShow] = useState(1);
  const [itemWidth, setItemsWidth] = useState(0);

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 1024) {
        setItemsToShow(4);
      } else if (window.innerWidth >= 768) {
        setItemsToShow(2);
      } else {
        setItemsToShow(1);
      }
    };
    window.addEventListener("resize", handleResize);
    handleResize();
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  const handlePrev = () => {
    const width = window.innerWidth;
    const elements = document.getElementsByClassName("colourcard");
    var imagelength = images.length;

    if (width > 768) {
      imagelength = images.length - 4;
      setItemsWidth(elements[0].offsetWidth / 13);
    } else if (width > 426) {
      imagelength = images.length - 2;
      setItemsWidth(elements[0].offsetWidth / 6 - 1.8);
    } else if (width > 20) {
      imagelength = images.length - 2;
      setItemsWidth(elements[0].offsetWidth / 3.2 - 2.8);
    } else {
      imagelength = images.length;
      setItemsWidth(elements[0].offsetWidth / 5);
    }

    const newIndex = (currentIndex - 1 + imagelength) % imagelength;
    setCurrentIndex(newIndex);
  };

  const handleNext = () => {
    const width = window.innerWidth;
    var imagelength = images.length;

    const elements = document.getElementsByClassName("colourcard");

    if (width > 768) {
      imagelength = images.length - 4;
      setItemsWidth(elements[0].offsetWidth / 13);
    } else if (width > 426) {
      imagelength = images.length - 2;
      setItemsWidth(elements[0].offsetWidth / 6 - 1.8);
    } else if (width > 20) {
      imagelength = images.length - 2;
      setItemsWidth(elements[0].offsetWidth / 3.2 - 2.8);
    } else {
      imagelength = images.length;
      setItemsWidth(elements[0].offsetWidth / 5);
    }

    const newIndex = (currentIndex + 1) % imagelength;
    setCurrentIndex(newIndex);
  };

  return (
    <motion.div
      className="relative flex flex-col w-full overflow-hidden gap-4"
      ref={ref1}
      initial={{ opacity: 0, y: -150 }} // Start off-screen
      animate={inView1 ? { opacity: 1, y: 0 } : { opacity: 0, y: 150 }} // Animate based on inView1
      transition={{ duration: 0.5, delay: 0.1 }}
    >
      <div className="flex flex-row items-center justify-between">
        <div className="flex flex-col justify-start lg:pl-4 text-left mb-3 lg:mb-0">
          <span className="text-[24px] font-semibold opacity-85 text-center lg:text-left">
            The Colours of Autumn
          </span>
          <span className="text-[13px] font-normal opacity-55 text-center lg:text-left">
            Embrace the enchanting hues of fall with our exquisite collection
          </span>
        </div>
        <div className="absolute lg:relative lg:top-0 lg:justify-end flex-row flex justify-between top-44 z-30 lg:flex lg:space-x-2 lg:self-end  lg:m-3 lg:w-min w-full">
          <button
            onClick={handlePrev}
            className="bg-white p-2 rounded-full shadow focus:ring-0 focus:border-none border-none ring-0 mx-3"
          >
            <AiOutlineLeft className="h-6 w-6 text-gray-800" />
          </button>
          <button
            onClick={handleNext}
            className="bg-white p-2 rounded-full shadow focus:ring-0 focus:border-none border-none ring-0 mx-3"
          >
            <AiOutlineRight className="h-6 w-6 text-gray-800" />
          </button>
        </div>
      </div>

      <div
        className="flex transition-transform duration-500"
        style={{
          transform: `translateX(-${
            currentIndex * itemWidth - currentIndex * 1.2
          }%)`,
        }}
      >
        {images.map((image, index) => (
          <motion.div
            key={index}
            className="flex flex-row gap-2"
            ref={ref1}
            initial={{ opacity: 0, y: -150 }} // Start off-screen
            animate={inView1 ? { opacity: 1, y: 0 } : { opacity: 0, y: 150 }} // Animate based on inView1
            transition={{ duration: 0.5, delay: 0.2 * index }}
          >
            <div className="colourcard flex flex-col justify-between items-center text-center gap-0 mx-2 w-[40vw] bg-[#fbfbfb] p-1 rounded-md hover:scale-105 transition-all duration-300 hover:bg-[#201e37] hover:text-gray-100 mb-8 md:w-[24vw] lg:w-[18vw] select-none ">
              <img
                src={image.src}
                alt={image.alt}
                className="rounded-md object-cover"
              />

              <span className="font-semibold text-[14px] lg:text-[16px] opacity-90 mt-6 ">
                {image.title}
              </span>
              <span className="text-[11px] lg:text-[13px] mt-0 mb-2 opacity-60">
                {image.no}
              </span>
            </div>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
};

export default Carousel;
