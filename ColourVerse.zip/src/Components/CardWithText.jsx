import React from "react";
import { useInView } from "react-intersection-observer";
import { motion } from "framer-motion";

const CardWithText = ({ id, imgSrc, title, text, buttonText }) => {
  const [ref1, inView1] = useInView({ triggerOnce: false, threshold: 0.1 });

  return (
    <motion.div
      id={id}
      className="flex lg:flex-row flex-col justify-center items-center overflow-hidden gap-4 "
      ref={ref1}
      initial={{ opacity: 0, y: -150 }} // Start off-screen
      animate={inView1 ? { opacity: 1, y: 0 } : { opacity: 0, y: 150 }} // Animate based on inView1
      transition={{ duration: 0.5, delay: 0.1 }}
    >
      <div className="flex mb-0  rounded-lg p-5 content-center overflow-hidden lg:w-auto h-[80vh]">
        <img src={imgSrc} alt={title} className=" rounded-lg object-cover" />
      </div>

      <div className="w-auto lg:w-auto pl-0 lg:pl-4 flex flex-col lg:justify-center justify-center items-center lg:items-start">
        {" "}
        {/* Align content to left */}
        <h2 className="lg:text-[30px] text-[22px] font-bold lg:mb-6 lg:text-left text-center">
          {title}
        </h2>
        <p className="mb-4 text-[15px] mx-10 lg:text-left text-wrap lg:mr-[4rem]  mt-3 w-auto lg:max-w-[36vw] opacity-75 text-center lg:ml-0">
          {text}
        </p>
        <button className="glass-button px-6 py-2 my-4 rounded-full lg:mt-8 mb-4 bg-[white] text-black hover:bg-slate-400 hover:text-white">
          {buttonText}
        </button>
      </div>
    </motion.div>
  );
};

export default CardWithText;
