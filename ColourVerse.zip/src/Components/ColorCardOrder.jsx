import React from "react";
import colorcardimage from "../assets/ColourCard.jpg";
import { useInView } from "react-intersection-observer";
import { motion } from "framer-motion";

const ColorCardOrder = () => {
  const [ref1, inView1] = useInView({ triggerOnce: false, threshold: 0.1 });
  return (
    <>
      <motion.div
        className="flex flex-col mt-4 lg:flex-row items-center justify-between px-6 lg:px-32 overflow-hidden  lg:py-6"
        ref={ref1}
        initial={{ opacity: 0, y: -150 }} // Start off-screen
        animate={inView1 ? { opacity: 1, y: 0 } : { opacity: 0, y: 150 }} // Animate based on inView1
        transition={{ duration: 0.5, delay: 0.1 }}
      >
        <img
          src={colorcardimage}
          alt="colorcard img"
          className=" rounded-full w-56"
        />
        <div className="flex flex-col justify-start mx-20 select-none w-full">
          <span className=" text-[18px] lg:text-[24px] lg-mt-0 mt-10 font-semibold opacity-90 text-center lg:text-left">
            Free Colour Card & Free Delivery
          </span>
          <span className="text-[12px] lg:text-[15px] mt-3 font-normal opacity-55  text-center lg:text-left">
            Discover our thoughtfully selected palette of 154 shades, each with
            a captivating story behind its name, to help you find the perfect
            colors for your home.
          </span>
        </div>
        <button className="px-6 py-2 text-[11px] lg:text-[14px] lg:h-[44px] lg:left-0 w-auto lg:w-[280px] rounded-full mt-8 mb-4 bg-[#201e37] whitespace-nowrap font-medium text-white hover:scale-110 duration-300 transition-all">
          Order Colour Card
        </button>
      </motion.div>
    </>
  );
};
export default ColorCardOrder;
