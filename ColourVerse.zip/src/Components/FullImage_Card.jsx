import React from "react";
import bgimg1 from "../assets/Lumines.jpg";
import { useInView } from "react-intersection-observer";
import { motion } from "framer-motion";

const FullImage_Card = () => {
  const [ref1, inView1] = useInView({ triggerOnce: false, threshold: 0.1 });

  return (
    <>
      <motion.div
        className="relative block my-20"
        ref={ref1}
        initial={{ opacity: 0, y: -150 }} // Start off-screen
        animate={inView1 ? { opacity: 1, y: 0 } : { opacity: 0, y: 150 }} // Animate based on inView1
        transition={{ duration: 0.5, delay: 0.1 }}
      >
        <div className="flex rounded-xl w-full overflow-hidden h-[90vh] ">
          <img src={bgimg1} alt="image" className="object-cover w-full top-9" />
        </div>
        <div className="flex justify-center">
          <div className="absolute w-[70vw] lg:w-[40vw] mx-auto top-8 lg:right-10 lg:top-8 z-50 flex md:flex lg:flex flex-col lg:gap-4 text-wrap lg:mx-4 md:mx-1 justify-center gap-3 bg-[#adbfd267] p-4 lg:p-10 rounded-[20px] lg:h-72 backdrop-blur-[15px] hover:scale-105 duration-700 transition-all">
            <span className="text-[18px] lg:text-[30px] md:text-[14px] font-semibold opacity-90 lg:text-left text-center lg:text-wrap">
              Latest Inspiration
            </span>
            <span className="lg:text-[15px] md:text-[12px] text-[12px]  font-normal opacity-75 lg:text-left text-center lg:text-wrap">
              Our emails are bursting with bright ideas. Sign up to get the
              latest Farrow & Ball news & keep touch with us to get latest
              updates.
            </span>
            <button className="px-6 mt-4 py-2 text-[13px] self-center lg:self-start  md:text-[12px] lg:text-[14px] w-auto lg:w-[200px] lg:h-[44px] rounded-full md:mt-2 lg:mt-8 lg:mb-4 bg-[#201e37] lg:font-medium text-white hover:scale-110 duration-300 transition-all hover:bg-[#334996] focus:ring-0 focus:border-none border-none ring-0">
              Sign me Up !
            </button>
          </div>
        </div>
      </motion.div>
    </>
  );
};

export default FullImage_Card;
