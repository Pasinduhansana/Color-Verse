import React from "react";
import { useInView } from "react-intersection-observer";
import { motion } from "framer-motion";
import wallpaper1 from "../assets/wallpaper.jpg";
import wallpaper2 from "../assets/wallpaper2.jpg";
import wallpaper3 from "../assets/wallpaper3.avif";

const StripeCard = () => {
  const [ref1, inView1] = useInView({ triggerOnce: false, threshold: 0.1 });
  return (
    <div className="flex flex-col lg:flex-row md:flex-row  mb-8 gap-4 justify-center items-center">
      <motion.div
        className="relative md:w-1/3 md:h-[200px] w-full h-[150px] group "
        ref={ref1}
        initial={{ opacity: 0, y: 150 }} // Start off-screen
        animate={inView1 ? { opacity: 1, y: 0 } : { opacity: 0, y: 150 }} // Animate based on inView1
        transition={{ duration: 0.5, delay: 0.2 }}
      >
        <img
          src={wallpaper1}
          alt="Inspiration"
          className="w-full h-full object-cover rounded-lg"
        />
        <div className="absolute inset-0 bg-transparent group-hover:bg-black group-hover:bg-opacity-50 flex items-center justify-center rounded-lg transition-all duration-300">
          <span className="text-white text-[30px] opacity-40 group-hover:scale-[1.8] transform transition-all duration-300 z-10">
            Inspiration
          </span>
        </div>
        <div className="absolute inset-0 bg-transparent group-hover:backdrop-blur-md rounded-lg transition-all duration-300"></div>
      </motion.div>
      <motion.div
        className="relative md:w-1/3 md:h-[200px] w-full h-[150px] group"
        ref={ref1}
        initial={{ opacity: 0, y: 150 }} // Start off-screen
        animate={inView1 ? { opacity: 1, y: 0 } : { opacity: 0, y: 150 }} // Animate based on inView1
        transition={{ duration: 0.5, delay: 0.4 }}
      >
        <img
          src={wallpaper3}
          alt="Paint"
          className="w-full h-full object-cover rounded-lg"
        />
        <div className="absolute inset-0 bg-transparent group-hover:bg-black group-hover:bg-opacity-50 flex items-center justify-center rounded-lg transition-all duration-300">
          <span className="text-white text-[30px] opacity-40 group-hover:scale-[1.8] transform transition-all duration-300 z-10">
            Paint
          </span>
        </div>
        <div className="absolute inset-0 bg-transparent group-hover:backdrop-blur-md rounded-lg transition-all duration-300"></div>
      </motion.div>
      <motion.div
        className="relative md:w-1/3 md:h-[200px] w-full h-[150px] group"
        ref={ref1}
        initial={{ opacity: 0, y: 150 }} // Start off-screen
        animate={inView1 ? { opacity: 1, y: 0 } : { opacity: 0, y: 150 }} // Animate based on inView1
        transition={{ duration: 0.5, delay: 0.6 }}
      >
        <img
          src={wallpaper2}
          alt="Wallpaper"
          className="w-full h-full object-cover rounded-lg"
        />
        <div className="absolute inset-0 bg-transparent group-hover:bg-black group-hover:bg-opacity-50 flex items-center justify-center rounded-lg transition-all duration-300">
          <span className="text-white text-[30px] opacity-40 group-hover:scale-[1.8] transform transition-all duration-300 z-10">
            Wallpaper
          </span>
        </div>
        <div className="absolute inset-0 bg-transparent group-hover:backdrop-blur-md rounded-lg transition-all duration-300"></div>
      </motion.div>
    </div>
  );
};

export default StripeCard;
